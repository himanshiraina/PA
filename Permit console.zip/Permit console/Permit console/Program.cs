﻿using System;
using System.Activities;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;  

namespace Permit_console
{
    class Program
    {
        static public void Main(string[] args)
        {
            Console.Title = "PL400.Permit.Console";
            Console.WriteLine("Permit console : Start");

            string userName = "admin@M365x25633610.onmicrosoft.com";
            string password = "hDB%a=^8;Y+6lxC270";
            string url = "https://orgd526baf8.api.crm.dynamics.com";

            string connectionString = "AuthType=OAuth;Username=" + userName + ";Password='" + password + "';Url=" + url + ";AppId=51f81489-12ee-4a9e-aaae-a2591f45987d;RedirectUri=app://58145B91-0C36-4500-8554-080854F2AC97;LoginPrompt=Auto";

            try
            {
                Console.WriteLine("Connect using XRM Tooling");
                CrmServiceClient crmSvc = new CrmServiceClient(connectionString);
                if (crmSvc.IsReady)
                    Console.WriteLine("Connected");
                else
                {
                    throw new Exception("Failed to connect");
                }

                Console.WriteLine("Version={0}", crmSvc.ConnectedOrgVersion);
                Console.WriteLine("Organization={0}", crmSvc.ConnectedOrgUniqueName);

                Console.WriteLine("Retrieve current user");
                Guid currentuserid = ((WhoAmIResponse)crmSvc.Execute(new WhoAmIRequest())).UserId;
                Entity systemUser = (Entity)crmSvc.Retrieve("systemuser", currentuserid, new ColumnSet(new string[] { "firstname", "lastname" }));
                Console.WriteLine("Logged on user is {0} {1}.", systemUser["firstname"], systemUser["lastname"]);

                // Data Operations
                Console.WriteLine("Create permit");
                Entity newPermit = new Entity("contoso_permit");
                newPermit["contoso_name"] = "Organization Service Permit";
                newPermit["contoso_newsize"] = 1000;
                newPermit["contoso_startdate"] = DateTime.Now;
                Guid permitid = crmSvc.Create(newPermit);
                Console.WriteLine("Permit={0}", permitid.ToString());
                Console.WriteLine("Retrieving inspections");
                QueryExpression inspectionsQuery = new QueryExpression
                {
                    EntityName = "contoso_inspection",
                    ColumnSet = new ColumnSet(false)
                };
                inspectionsQuery.ColumnSet.AddColumn("contoso_permit");
                inspectionsQuery.ColumnSet.AddColumn("contoso_name");
                inspectionsQuery.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 330650001);
                inspectionsQuery.Distinct = true;
                EntityCollection inspections = crmSvc.RetrieveMultiple(inspectionsQuery);
                Console.WriteLine("Number of Pending Inspections=" + inspections.Entities.Count.ToString());
            
             foreach (Entity inspection in inspections.Entities)
            {
                EntityReference permit = (EntityReference)inspection["contoso_permit"];
                Console.WriteLine("Inspection {0} {1} {2}", permit.Id.ToString(), permit.Name, inspection["contoso_name"]);
            }


                Console.WriteLine("Permit console : End");
                // Pause the console so it does not close.
                Console.WriteLine("Press the <Enter> key to exit.");
                Console.ReadLine();
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
        }
    }
}
